var searchData=
[
  ['fijar_5fcontexto_5fssl',['fijar_contexto_SSL',['../d8/d51/_g-2301-05-_p3-ssl_8h.html#a84a295d51a23d2558cbf65f436011dc6',1,'fijar_contexto_SSL(char *CAfile, char *SCfile, char *Pfile, char *CApath):&#160;G-2301-05-P3-ssl.c'],['../d8/d7e/_g-2301-05-_p3-ssl_8c.html#a84a295d51a23d2558cbf65f436011dc6',1,'fijar_contexto_SSL(char *CAfile, char *SCfile, char *Pfile, char *CApath):&#160;G-2301-05-P3-ssl.c'],['../d8/db1/group___i_r_cssl.html',1,'(Global Namespace)']]],
  ['file_5fbuflen',['FILE_BUFLEN',['../da/d15/_g-2301-05-_p2-basic_commands_from_server_8h.html#ab4280385e15a48712d64d651acb2648d',1,'G-2301-05-P2-basicCommandsFromServer.h']]],
  ['filename',['filename',['../d4/d4e/structthread_recv_args.html#aeac90097f29f7529968697163cea5c18',1,'threadRecvArgs::filename()'],['../d7/d51/structthread_send_args.html#aeac90097f29f7529968697163cea5c18',1,'threadSendArgs::filename()']]],
  ['filterusersinchannels',['filterUsersInChannels',['../df/db1/_g-2301-05-_p1-commands_8c.html#a02944755d02164cf484a4c933ed2f0c3',1,'G-2301-05-P1-commands.c']]],
  ['freethreadresources',['freeThreadResources',['../d6/d77/_g-2301-05-_p1-server_8c.html#a492f3eb1b5fd2db5f809828bcaeb8759',1,'freeThreadResources(int socket):&#160;G-2301-05-P1-server.c'],['../d6/d48/servidor___i_r_c_8c.html#a492f3eb1b5fd2db5f809828bcaeb8759',1,'freeThreadResources(int socket):&#160;servidor_IRC.c']]],
  ['fsend_5fparse',['FSend_Parse',['../d9/d8f/_g-2301-05-_p2-basic_commands_from_server_8c.html#ad2ca292b4e5365950f6ea7887abdbc37',1,'G-2301-05-P2-basicCommandsFromServer.c']]],
  ['functs',['functs',['../d6/d77/_g-2301-05-_p1-server_8c.html#a3b74f15bfc2af0a575608c31e269694a',1,'functs():&#160;G-2301-05-P1-server.c'],['../dd/dbf/_g-2301-05-_p2-xchat2_8c.html#a3b74f15bfc2af0a575608c31e269694a',1,'functs():&#160;G-2301-05-P2-xchat2.c'],['../d6/d48/servidor___i_r_c_8c.html#aeb1032d8268ea693782bef5c39d10e94',1,'functs():&#160;servidor_IRC.c']]]
];
