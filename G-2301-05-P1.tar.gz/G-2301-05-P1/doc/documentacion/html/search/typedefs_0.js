var searchData=
[
  ['pfuncs',['pFuncs',['../d6/d77/_g-2301-05-_p1-server_8c.html#af4fbc62d68085a32b47e88d447b77b28',1,'pFuncs():&#160;G-2301-05-P1-server.c'],['../dd/dbf/_g-2301-05-_p2-xchat2_8c.html#a4b932f95396d02e0a0c48dfab971852a',1,'pFuncs():&#160;G-2301-05-P2-xchat2.c'],['../d6/d48/servidor___i_r_c_8c.html#af4fbc62d68085a32b47e88d447b77b28',1,'pFuncs():&#160;servidor_IRC.c']]],
  ['puserfuncs',['pUserFuncs',['../dd/dbf/_g-2301-05-_p2-xchat2_8c.html#aa0f4db7da8ca28c8ec5521d8825a83ea',1,'G-2301-05-P2-xchat2.c']]]
];
