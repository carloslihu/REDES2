var searchData=
[
  ['audio_5fbuflen',['AUDIO_BUFLEN',['../d6/dbc/_g-2301-05-_p2-audio_8c.html#a88007cd1caf5537d34251bcc91704402',1,'G-2301-05-P2-audio.c']]]
];
