var searchData=
[
  ['daemonizar_2ec',['daemonizar.c',['../dc/d4a/daemonizar_8c.html',1,'']]],
  ['daemonizar_2eh',['daemonizar.h',['../da/de5/daemonizar_8h.html',1,'']]]
];
