var searchData=
[
  ['hostname',['hostname',['../d4/d4e/structthread_recv_args.html#af203df082d5c6dcaa0c88b07cf86466d',1,'threadRecvArgs::hostname()'],['../d1/d22/structthread_audio_args.html#af203df082d5c6dcaa0c88b07cf86466d',1,'threadAudioArgs::hostname()'],['../d6/d77/_g-2301-05-_p1-server_8c.html#af203df082d5c6dcaa0c88b07cf86466d',1,'hostname():&#160;G-2301-05-P1-server.c'],['../d6/d48/servidor___i_r_c_8c.html#af203df082d5c6dcaa0c88b07cf86466d',1,'hostname():&#160;servidor_IRC.c']]]
];
