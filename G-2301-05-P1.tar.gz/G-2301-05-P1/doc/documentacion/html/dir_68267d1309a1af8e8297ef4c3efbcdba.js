var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "daemonizar", "dir_c75cb953fb6f1a05ae328961a93499aa.html", "dir_c75cb953fb6f1a05ae328961a93499aa" ],
    [ "cliente_echo.c", "d4/d18/cliente__echo_8c.html", "d4/d18/cliente__echo_8c" ],
    [ "cliente_IRC.c", "de/dee/cliente___i_r_c_8c.html", "de/dee/cliente___i_r_c_8c" ],
    [ "G-2301-05-P1-client.c", "df/dcc/_g-2301-05-_p1-client_8c.html", "df/dcc/_g-2301-05-_p1-client_8c" ],
    [ "G-2301-05-P1-commands.c", "df/db1/_g-2301-05-_p1-commands_8c.html", "df/db1/_g-2301-05-_p1-commands_8c" ],
    [ "G-2301-05-P1-server.c", "d6/d77/_g-2301-05-_p1-server_8c.html", "d6/d77/_g-2301-05-_p1-server_8c" ],
    [ "G-2301-05-P2-audio.c", "d6/dbc/_g-2301-05-_p2-audio_8c.html", "d6/dbc/_g-2301-05-_p2-audio_8c" ],
    [ "G-2301-05-P2-basicCommandsFromServer.c", "d9/d8f/_g-2301-05-_p2-basic_commands_from_server_8c.html", "d9/d8f/_g-2301-05-_p2-basic_commands_from_server_8c" ],
    [ "G-2301-05-P2-repliesFromServer.c", "d7/de8/_g-2301-05-_p2-replies_from_server_8c.html", "d7/de8/_g-2301-05-_p2-replies_from_server_8c" ],
    [ "G-2301-05-P2-userCommands.c", "d6/dbe/_g-2301-05-_p2-user_commands_8c.html", "d6/dbe/_g-2301-05-_p2-user_commands_8c" ],
    [ "G-2301-05-P2-userTools.c", "d8/da8/_g-2301-05-_p2-user_tools_8c.html", "d8/da8/_g-2301-05-_p2-user_tools_8c" ],
    [ "G-2301-05-P2-xchat2.c", "dd/dbf/_g-2301-05-_p2-xchat2_8c.html", "dd/dbf/_g-2301-05-_p2-xchat2_8c" ],
    [ "servidor_echo.c", "d3/dbb/servidor__echo_8c.html", "d3/dbb/servidor__echo_8c" ],
    [ "servidor_IRC.c", "d6/d48/servidor___i_r_c_8c.html", "d6/d48/servidor___i_r_c_8c" ]
];