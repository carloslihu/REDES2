var _g_2301_05__p1_server_8c =
[
    [ "threadArgs", "d3/df7/structthread_args.html", "d3/df7/structthread_args" ],
    [ "THREAD_NUMBER", "d6/d77/_g-2301-05-_p1-server_8c.html#adc5a02a0d82a5e7fd93802b082e24102", null ],
    [ "pFuncs", "d6/d77/_g-2301-05-_p1-server_8c.html#af4fbc62d68085a32b47e88d447b77b28", null ],
    [ "connectAndRegister", "d6/d77/_g-2301-05-_p1-server_8c.html#ab7b31b719e6de8a7c05105d5e78e4ede", null ],
    [ "freeThreadResources", "d6/d77/_g-2301-05-_p1-server_8c.html#a492f3eb1b5fd2db5f809828bcaeb8759", null ],
    [ "main", "d6/d77/_g-2301-05-_p1-server_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "retrieveMsg", "d6/d77/_g-2301-05-_p1-server_8c.html#ae14d3432467a785bafce07c4ce2db219", null ],
    [ "threadPing", "d6/d77/_g-2301-05-_p1-server_8c.html#af073aef8b7cf446e542c8ef5002b27bc", null ],
    [ "threadRoutine", "d6/d77/_g-2301-05-_p1-server_8c.html#ac4e891ecfd0442a988ac4b2e1b88b796", null ],
    [ "functs", "d6/d77/_g-2301-05-_p1-server_8c.html#a3b74f15bfc2af0a575608c31e269694a", null ],
    [ "hostname", "d6/d77/_g-2301-05-_p1-server_8c.html#af203df082d5c6dcaa0c88b07cf86466d", null ],
    [ "mutex", "d6/d77/_g-2301-05-_p1-server_8c.html#a4acff8232e4aec9cd5c6dc200ac55ef3", null ]
];