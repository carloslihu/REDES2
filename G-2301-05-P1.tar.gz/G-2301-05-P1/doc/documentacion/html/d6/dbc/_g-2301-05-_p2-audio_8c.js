var _g_2301_05__p2_audio_8c =
[
    [ "AUDIO_BUFLEN", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a88007cd1caf5537d34251bcc91704402", null ],
    [ "alreadyRecordingQuery", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a23e6ef186ace7452878618e453a12d6f", null ],
    [ "canIRead", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a70e78aa07a05a7d1d6688220b711fe0d", null ],
    [ "canIWrite", "d6/dbc/_g-2301-05-_p2-audio_8c.html#acddb1a586a8305d216deca1d3bd07c29", null ],
    [ "endAudioTransmission", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a2140fd94315d561f0df0972d18f144cc", null ],
    [ "initiateReciever", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a4d496518d4597c6f8133d109caaf988a", null ],
    [ "initiateSender", "d6/dbc/_g-2301-05-_p2-audio_8c.html#aba2d08b3de022fdec5162252fe5d3dd8", null ],
    [ "playBuffer", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a46e32d8c31f4e0bed7c4a3dd7665ba73", null ],
    [ "playThread", "d6/dbc/_g-2301-05-_p2-audio_8c.html#ab32c5c00416d29c7b60bc91e53cef43a", null ],
    [ "writeBuffer", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a197e00439b5ca776c65aba209872f76a", null ],
    [ "audioBuffer", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a5910b24e625d530fb8ff50b0dcef805a", null ],
    [ "grabandoAudio", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a991a654ebc130040f9ca67c7a4c1956d", null ],
    [ "readPos", "d6/dbc/_g-2301-05-_p2-audio_8c.html#ae80c1a9f4c0091ea6d461132b9457a4c", null ],
    [ "writePos", "d6/dbc/_g-2301-05-_p2-audio_8c.html#a8693afd6c4562264a3cb24736198e435", null ]
];