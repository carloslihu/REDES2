var group___i_r_c_server_tools =
[
    [ "daemonizar", "d1/d75/group___i_r_c_server_tools.html#daemonizar", null ],
    [ "logIntError", "d1/d75/group___i_r_c_server_tools.html#logIntError", null ],
    [ "logPointerError", "d1/d75/group___i_r_c_server_tools.html#logPointerError", null ],
    [ "logVoidError", "d1/d75/group___i_r_c_server_tools.html#logVoidError", null ],
    [ "getIP", "d1/d75/group___i_r_c_server_tools.html#getIP", null ],
    [ "getHostName", "d1/d75/group___i_r_c_server_tools.html#getHostName", null ],
    [ "getNickFromSocket", "d1/d75/group___i_r_c_server_tools.html#getNickFromSocket", null ],
    [ "getSocketFromNick", "d1/d75/group___i_r_c_server_tools.html#getSocketFromNick", null ],
    [ "getAwayFromSocket", "d1/d75/group___i_r_c_server_tools.html#getAwayFromSocket", null ]
];