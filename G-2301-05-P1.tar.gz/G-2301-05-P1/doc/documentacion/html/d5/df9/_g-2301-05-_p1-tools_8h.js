var _g_2301_05__p1_tools_8h =
[
    [ "daemonizar", "d5/df9/_g-2301-05-_p1-tools_8h.html#a79f6ea5350079c571138b0a00af1f5a4", null ],
    [ "getAwayFromSocket", "d5/df9/_g-2301-05-_p1-tools_8h.html#a2aa2c8c4d6f3b48dd3c195beff08eb0b", null ],
    [ "getHostName", "d5/df9/_g-2301-05-_p1-tools_8h.html#a3101bc13b5c20c8b430348441050ae9d", null ],
    [ "getIP", "d5/df9/_g-2301-05-_p1-tools_8h.html#a2850885f03b7654d239b361940416bef", null ],
    [ "getNickFromSocket", "d5/df9/_g-2301-05-_p1-tools_8h.html#af3b23798269ccab05560708cc1a22a92", null ],
    [ "getSocketFromNick", "d5/df9/_g-2301-05-_p1-tools_8h.html#a100eca1a277dd50fc2e289763dad8464", null ],
    [ "logIntError", "d5/df9/_g-2301-05-_p1-tools_8h.html#a6349dfcf345b8d45a1be65e3e17739fe", null ],
    [ "logPointerError", "d5/df9/_g-2301-05-_p1-tools_8h.html#a192fd5bf4f47fe63d449f291f92732a9", null ],
    [ "logVoidError", "d5/df9/_g-2301-05-_p1-tools_8h.html#a5b92fdc34c0427eb5cf8360e68aa9287", null ]
];