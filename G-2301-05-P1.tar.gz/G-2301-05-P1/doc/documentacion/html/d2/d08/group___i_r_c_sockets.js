var group___i_r_c_sockets =
[
    [ "openSocket_TCP", "d2/d08/group___i_r_c_sockets.html#openSocket_TCP", null ],
    [ "bindSocket_TCP", "d2/d08/group___i_r_c_sockets.html#bindSocket_TCP", null ],
    [ "acceptConnection", "d2/d08/group___i_r_c_sockets.html#acceptConnection", null ],
    [ "connectTo", "d2/d08/group___i_r_c_sockets.html#connectTo", null ],
    [ "connectToIP", "d2/d08/group___i_r_c_sockets.html#connectToIP", null ],
    [ "openSocket_UDP", "d2/d08/group___i_r_c_sockets.html#openSocket_UDP", null ],
    [ "bindSocket_UDP", "d2/d08/group___i_r_c_sockets.html#bindSocket_UDP", null ],
    [ "getSocketPort", "d2/d08/group___i_r_c_sockets.html#getSocketPort", null ],
    [ "iniAddrUDP", "d2/d08/group___i_r_c_sockets.html#iniAddrUDP", null ]
];