var group___i_r_c_audio =
[
    [ "initiateReciever", "d2/dc8/group___i_r_c_audio.html#initiateReciever", null ],
    [ "initiateSender", "d2/dc8/group___i_r_c_audio.html#initiateSender", null ],
    [ "canIRead", "d2/dc8/group___i_r_c_audio.html#canIRead", null ],
    [ "canIWrite", "d2/dc8/group___i_r_c_audio.html#canIWrite", null ],
    [ "writeBuffer", "d2/dc8/group___i_r_c_audio.html#writeBuffer", null ],
    [ "playBuffer", "d2/dc8/group___i_r_c_audio.html#playBuffer", null ],
    [ "alreadyRecordingQuery", "d2/dc8/group___i_r_c_audio.html#alreadyRecordingQuery", null ],
    [ "endAudioTransmission", "d2/dc8/group___i_r_c_audio.html#endAudioTransmission", null ]
];