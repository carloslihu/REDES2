var group___i_r_c_user_tools =
[
    [ "printXchat", "d2/d99/group___i_r_c_user_tools.html#printXchat", null ],
    [ "getMyNick", "d2/d99/group___i_r_c_user_tools.html#getMyNick", null ],
    [ "getMyNickThread", "d2/d99/group___i_r_c_user_tools.html#getMyNickThread", null ]
];