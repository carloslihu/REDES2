var group___i_r_c_user_commands =
[
    [ "isCommand", "d7/d37/group___i_r_c_user_commands.html#isCommand", null ],
    [ "userDefault", "d7/d37/group___i_r_c_user_commands.html#userDefault", null ],
    [ "userAway", "d7/d37/group___i_r_c_user_commands.html#userAway", null ],
    [ "userJoin", "d7/d37/group___i_r_c_user_commands.html#userJoin", null ],
    [ "userKick", "d7/d37/group___i_r_c_user_commands.html#userKick", null ],
    [ "userList", "d7/d37/group___i_r_c_user_commands.html#userList", null ],
    [ "userMode", "d7/d37/group___i_r_c_user_commands.html#userMode", null ],
    [ "userMotd", "d7/d37/group___i_r_c_user_commands.html#userMotd", null ],
    [ "userNames", "d7/d37/group___i_r_c_user_commands.html#userNames", null ],
    [ "userNick", "d7/d37/group___i_r_c_user_commands.html#userNick", null ],
    [ "userPart", "d7/d37/group___i_r_c_user_commands.html#userPart", null ],
    [ "userPriv", "d7/d37/group___i_r_c_user_commands.html#userPriv", null ],
    [ "userQuit", "d7/d37/group___i_r_c_user_commands.html#userQuit", null ],
    [ "userTopic", "d7/d37/group___i_r_c_user_commands.html#userTopic", null ],
    [ "userWhois", "d7/d37/group___i_r_c_user_commands.html#userWhois", null ],
    [ "userWho", "d7/d37/group___i_r_c_user_commands.html#userWho", null ]
];