var daemonizar_8c =
[
    [ "daemonizar", "dc/d4a/daemonizar_8c.html#a79f6ea5350079c571138b0a00af1f5a4", null ]
];