var dir_c75cb953fb6f1a05ae328961a93499aa =
[
    [ "daemonizar.c", "dc/d4a/daemonizar_8c.html", "dc/d4a/daemonizar_8c" ],
    [ "daemonizar.h", "da/de5/daemonizar_8h.html", "da/de5/daemonizar_8h" ],
    [ "prueba.c", "de/df7/prueba_8c.html", "de/df7/prueba_8c" ]
];