var _g_2301_05__p1_socket_8c =
[
    [ "acceptConnection", "dd/da3/_g-2301-05-_p1-socket_8c.html#ab2765e4508bc50655fe3dd36139f33a5", null ],
    [ "bindSocket_TCP", "dd/da3/_g-2301-05-_p1-socket_8c.html#a5ebfd6c6e35ddca1d74ca6a323cbab3e", null ],
    [ "bindSocket_UDP", "dd/da3/_g-2301-05-_p1-socket_8c.html#aed488b731e5ab644507ef7acf6376f8b", null ],
    [ "connectTo", "dd/da3/_g-2301-05-_p1-socket_8c.html#a688c9a3a3e37e99d810e8ad63984272d", null ],
    [ "connectToIP", "dd/da3/_g-2301-05-_p1-socket_8c.html#a073081b694c616f3485110ff67b6cc5a", null ],
    [ "getSocketPort", "dd/da3/_g-2301-05-_p1-socket_8c.html#a96661287c5bdb47422cfa55ad14506aa", null ],
    [ "iniAddrUDP", "dd/da3/_g-2301-05-_p1-socket_8c.html#aac80c67421f8d89f4d5614187dc9cb43", null ],
    [ "openSocket_TCP", "dd/da3/_g-2301-05-_p1-socket_8c.html#ac0a294efde364937332533e4ecd8d121", null ],
    [ "openSocket_UDP", "dd/da3/_g-2301-05-_p1-socket_8c.html#abbf23148d1fb659c277f1c4cf3726f54", null ]
];