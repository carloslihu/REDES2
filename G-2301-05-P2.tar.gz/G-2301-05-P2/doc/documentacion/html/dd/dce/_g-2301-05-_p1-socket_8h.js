var _g_2301_05__p1_socket_8h =
[
    [ "SERVERINFO", "dd/dce/_g-2301-05-_p1-socket_8h.html#a6cd6cae86cd5361650f9672609970907", null ],
    [ "SERVERNAME", "dd/dce/_g-2301-05-_p1-socket_8h.html#aab4f68861c2e03b2a78c37c2213cb350", null ],
    [ "acceptConnection", "dd/dce/_g-2301-05-_p1-socket_8h.html#ae610867398c76f4226d89666d2e2646e", null ],
    [ "bindSocket_TCP", "dd/dce/_g-2301-05-_p1-socket_8h.html#a5ebfd6c6e35ddca1d74ca6a323cbab3e", null ],
    [ "bindSocket_UDP", "dd/dce/_g-2301-05-_p1-socket_8h.html#aed488b731e5ab644507ef7acf6376f8b", null ],
    [ "connectTo", "dd/dce/_g-2301-05-_p1-socket_8h.html#a688c9a3a3e37e99d810e8ad63984272d", null ],
    [ "connectToIP", "dd/dce/_g-2301-05-_p1-socket_8h.html#a073081b694c616f3485110ff67b6cc5a", null ],
    [ "getSocketPort", "dd/dce/_g-2301-05-_p1-socket_8h.html#acf6e7bb836ff2442df28511544abf966", null ],
    [ "iniAddrUDP", "dd/dce/_g-2301-05-_p1-socket_8h.html#aac80c67421f8d89f4d5614187dc9cb43", null ],
    [ "openSocket_TCP", "dd/dce/_g-2301-05-_p1-socket_8h.html#ac0a294efde364937332533e4ecd8d121", null ],
    [ "openSocket_UDP", "dd/dce/_g-2301-05-_p1-socket_8h.html#abbf23148d1fb659c277f1c4cf3726f54", null ]
];