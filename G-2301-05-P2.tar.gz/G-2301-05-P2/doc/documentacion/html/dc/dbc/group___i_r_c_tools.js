var group___i_r_c_tools =
[
    [ "sockets", "d2/d08/group___i_r_c_sockets.html", "d2/d08/group___i_r_c_sockets" ],
    [ "serverTools", "d1/d75/group___i_r_c_server_tools.html", "d1/d75/group___i_r_c_server_tools" ],
    [ "userTools", "d2/d99/group___i_r_c_user_tools.html", "d2/d99/group___i_r_c_user_tools" ]
];