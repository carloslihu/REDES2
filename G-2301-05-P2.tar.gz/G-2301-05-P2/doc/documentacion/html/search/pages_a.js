var searchData=
[
  ['opensocket_5ftcp',['openSocket_TCP',['../d2/d08/group___i_r_c_sockets.html',1,'']]],
  ['opensocket_5fudp',['openSocket_UDP',['../d2/d08/group___i_r_c_sockets.html',1,'']]]
];
