var searchData=
[
  ['megasend',['megaSend',['../d4/d9b/group___i_r_c_server_commands.html',1,'']]]
];
