var searchData=
[
  ['port',['port',['../d4/d4e/structthread_recv_args.html#a63c89c04d1feae07ca35558055155ffb',1,'threadRecvArgs::port()'],['../d1/d22/structthread_audio_args.html#a63c89c04d1feae07ca35558055155ffb',1,'threadAudioArgs::port()']]]
];
