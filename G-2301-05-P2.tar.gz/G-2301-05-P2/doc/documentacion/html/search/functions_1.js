var searchData=
[
  ['bindsocket_5ftcp',['bindSocket_TCP',['../dd/dce/_g-2301-05-_p1-socket_8h.html#a5ebfd6c6e35ddca1d74ca6a323cbab3e',1,'bindSocket_TCP(int sockfd, int portno, struct sockaddr_in *serv_addr):&#160;G-2301-05-P1-socket.c'],['../dd/da3/_g-2301-05-_p1-socket_8c.html#a5ebfd6c6e35ddca1d74ca6a323cbab3e',1,'bindSocket_TCP(int sockfd, int portno, struct sockaddr_in *serv_addr):&#160;G-2301-05-P1-socket.c']]],
  ['bindsocket_5fudp',['bindSocket_UDP',['../dd/dce/_g-2301-05-_p1-socket_8h.html#aed488b731e5ab644507ef7acf6376f8b',1,'bindSocket_UDP(int sockfd, int portno, struct sockaddr_in *serv_addr):&#160;G-2301-05-P1-socket.c'],['../dd/da3/_g-2301-05-_p1-socket_8c.html#aed488b731e5ab644507ef7acf6376f8b',1,'bindSocket_UDP(int sockfd, int portno, struct sockaddr_in *serv_addr):&#160;G-2301-05-P1-socket.c']]]
];
