var structthread_send_args =
[
    [ "data", "d7/d51/structthread_send_args.html#a91a70b77df95bd8b0830b49a094c2acb", null ],
    [ "filename", "d7/d51/structthread_send_args.html#aeac90097f29f7529968697163cea5c18", null ],
    [ "length", "d7/d51/structthread_send_args.html#a90bf0058c728d7cea7de336a1251f387", null ],
    [ "nick", "d7/d51/structthread_send_args.html#a89f27568c92a418413e6b37b41f07e21", null ]
];