var annotated =
[
    [ "threadArgs", "d3/df7/structthread_args.html", "d3/df7/structthread_args" ],
    [ "threadAudioArgs", "d1/d22/structthread_audio_args.html", "d1/d22/structthread_audio_args" ],
    [ "threadRecvArgs", "d4/d4e/structthread_recv_args.html", "d4/d4e/structthread_recv_args" ],
    [ "threadSendArgs", "d7/d51/structthread_send_args.html", "d7/d51/structthread_send_args" ]
];