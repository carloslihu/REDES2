var _g_2301_05__p2_user_tools_8c =
[
    [ "getMyNick", "d8/da8/_g-2301-05-_p2-user_tools_8c.html#afc2d4ce661d2f13fbe4b5518d778d071", null ],
    [ "getMyNickThread", "d8/da8/_g-2301-05-_p2-user_tools_8c.html#ab409491dfa3ca1ed9713df0eabdb70ed", null ],
    [ "printXchat", "d8/da8/_g-2301-05-_p2-user_tools_8c.html#a3e267cdf9839a331d371dd5f980d153e", null ]
];