var daemonizar_8h =
[
    [ "daemonizar", "da/de5/daemonizar_8h.html#a79f6ea5350079c571138b0a00af1f5a4", null ]
];