var _g_2301_05__p1_client_8c =
[
    [ "error", "df/dcc/_g-2301-05-_p1-client_8c.html#a4866b2d37ffc80c5ba705d3fcd1e0ecf", null ],
    [ "main", "df/dcc/_g-2301-05-_p1-client_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];