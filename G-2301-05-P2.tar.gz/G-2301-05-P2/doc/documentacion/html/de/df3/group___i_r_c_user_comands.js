var group___i_r_c_user_comands =
[
    [ "isCommand", "de/df3/group___i_r_c_user_comands.html#isCommand", null ],
    [ "userDefault", "de/df3/group___i_r_c_user_comands.html#userDefault", null ],
    [ "userAway", "de/df3/group___i_r_c_user_comands.html#userAway", null ],
    [ "userJoin", "de/df3/group___i_r_c_user_comands.html#userJoin", null ],
    [ "userKick", "de/df3/group___i_r_c_user_comands.html#userKick", null ],
    [ "userList", "de/df3/group___i_r_c_user_comands.html#userList", null ],
    [ "userMode", "de/df3/group___i_r_c_user_comands.html#userMode", null ],
    [ "userMotd", "de/df3/group___i_r_c_user_comands.html#userMotd", null ],
    [ "userNames", "de/df3/group___i_r_c_user_comands.html#userNames", null ],
    [ "userNick", "de/df3/group___i_r_c_user_comands.html#userNick", null ],
    [ "userPart", "de/df3/group___i_r_c_user_comands.html#userPart", null ],
    [ "userPriv", "de/df3/group___i_r_c_user_comands.html#userPriv", null ],
    [ "userQuit", "de/df3/group___i_r_c_user_comands.html#userQuit", null ],
    [ "userTopic", "de/df3/group___i_r_c_user_comands.html#userTopic", null ],
    [ "userWhois", "de/df3/group___i_r_c_user_comands.html#userWhois", null ],
    [ "userWho", "de/df3/group___i_r_c_user_comands.html#userWho", null ]
];