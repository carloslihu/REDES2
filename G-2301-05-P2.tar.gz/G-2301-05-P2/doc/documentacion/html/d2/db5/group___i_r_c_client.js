var group___i_r_c_client =
[
    [ "audio", "d2/dc8/group___i_r_c_audio.html", "d2/dc8/group___i_r_c_audio" ],
    [ "commandsFromServer", "d5/df5/group___i_r_c_commands_from_server.html", "d5/df5/group___i_r_c_commands_from_server" ],
    [ "repliesFromServer", "d7/d0c/group___i_r_creplies_from_server.html", "d7/d0c/group___i_r_creplies_from_server" ],
    [ "userCommands", "d7/d37/group___i_r_c_user_commands.html", "d7/d37/group___i_r_c_user_commands" ]
];