var group___i_r_c_server_commands =
[
    [ "commandDefault", "d4/d9b/group___i_r_c_server_commands.html#commandDefault", null ],
    [ "commandNick", "d4/d9b/group___i_r_c_server_commands.html#commandNick", null ],
    [ "commandMode", "d4/d9b/group___i_r_c_server_commands.html#commandMode", null ],
    [ "commandQuit", "d4/d9b/group___i_r_c_server_commands.html#commandQuit", null ],
    [ "commandJoin", "d4/d9b/group___i_r_c_server_commands.html#commandJoin", null ],
    [ "commandPart", "d4/d9b/group___i_r_c_server_commands.html#commandPart", null ],
    [ "commandTopic", "d4/d9b/group___i_r_c_server_commands.html#commandTopic", null ],
    [ "commandNames", "d4/d9b/group___i_r_c_server_commands.html#commandNames", null ],
    [ "commandList", "d4/d9b/group___i_r_c_server_commands.html#commandList", null ],
    [ "commandKick", "d4/d9b/group___i_r_c_server_commands.html#commandKick", null ],
    [ "commandPrivmsg", "d4/d9b/group___i_r_c_server_commands.html#commandPrivmsg", null ],
    [ "commandMotd", "d4/d9b/group___i_r_c_server_commands.html#commandMotd", null ],
    [ "commandWhois", "d4/d9b/group___i_r_c_server_commands.html#commandWhois", null ],
    [ "commandPing", "d4/d9b/group___i_r_c_server_commands.html#commandPing", null ],
    [ "commandAway", "d4/d9b/group___i_r_c_server_commands.html#commandAway", null ],
    [ "commandWho", "d4/d9b/group___i_r_c_server_commands.html#commandWho", null ],
    [ "megaSend", "d4/d9b/group___i_r_c_server_commands.html#megaSend", null ]
];