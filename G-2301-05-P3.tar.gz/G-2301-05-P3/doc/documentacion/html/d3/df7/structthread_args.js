var structthread_args =
[
    [ "client", "d3/df7/structthread_args.html#a00c4b9e068a2d36291a8410badf19e85", null ],
    [ "ctx", "d3/df7/structthread_args.html#ad5433bcc8a463fb4df3ce5912bb11fe3", null ],
    [ "server", "d3/df7/structthread_args.html#a174501e91471cbe22c45a3a89a932d62", null ],
    [ "socket", "d3/df7/structthread_args.html#a3666576f6b88007cc7b8f26c7da596c8", null ],
    [ "ssl", "d3/df7/structthread_args.html#ae7c0417fa2881f3546920311fee80311", null ]
];