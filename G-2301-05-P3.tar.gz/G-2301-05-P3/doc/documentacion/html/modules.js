var modules =
[
    [ "server", "da/d6d/group___i_r_c_server.html", "da/d6d/group___i_r_c_server" ],
    [ "tools", "dc/dbc/group___i_r_c_tools.html", "dc/dbc/group___i_r_c_tools" ],
    [ "client", "d2/db5/group___i_r_c_client.html", "d2/db5/group___i_r_c_client" ],
    [ "ssl", "d8/db1/group___i_r_cssl.html", "d8/db1/group___i_r_cssl" ],
    [ "Interface", "df/d29/group___i_r_c_interface.html", "df/d29/group___i_r_c_interface" ]
];