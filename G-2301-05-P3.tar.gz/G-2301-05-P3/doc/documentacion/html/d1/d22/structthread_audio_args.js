var structthread_audio_args =
[
    [ "hostname", "d1/d22/structthread_audio_args.html#af203df082d5c6dcaa0c88b07cf86466d", null ],
    [ "port", "d1/d22/structthread_audio_args.html#a63c89c04d1feae07ca35558055155ffb", null ],
    [ "sender", "d1/d22/structthread_audio_args.html#ab092ba1f84e458809eb91a5786b281de", null ]
];