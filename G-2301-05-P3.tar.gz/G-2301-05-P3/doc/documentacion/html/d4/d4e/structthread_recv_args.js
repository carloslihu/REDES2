var structthread_recv_args =
[
    [ "filename", "d4/d4e/structthread_recv_args.html#aeac90097f29f7529968697163cea5c18", null ],
    [ "hostname", "d4/d4e/structthread_recv_args.html#af203df082d5c6dcaa0c88b07cf86466d", null ],
    [ "length", "d4/d4e/structthread_recv_args.html#a9ee64c7b918513891b3834b93ad0e501", null ],
    [ "port", "d4/d4e/structthread_recv_args.html#a63c89c04d1feae07ca35558055155ffb", null ],
    [ "sender", "d4/d4e/structthread_recv_args.html#abe5ba910d6dc4c312cb722de3ab377f2", null ]
];