var _g_2301_05__p2_user_tools_8h =
[
    [ "PORT_RECORD", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#a403f3d61e6c0872cda3700219ca9ac1e", null ],
    [ "PORT_SEND", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#a40c5426015ecc21e39dfb362eb4c0c14", null ],
    [ "SIZE", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#a70ed59adcb4159ac551058053e649640", null ],
    [ "getMyNick", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#afc2d4ce661d2f13fbe4b5518d778d071", null ],
    [ "getMyNickThread", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#ab409491dfa3ca1ed9713df0eabdb70ed", null ],
    [ "printXchat", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#a3e267cdf9839a331d371dd5f980d153e", null ],
    [ "sockfd", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html#ad2c8fb3df3a737e0685e902870a611d2", null ]
];