var files =
[
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "srclib", "dir_055525a30e828dc7e51b22601599d317.html", "dir_055525a30e828dc7e51b22601599d317" ],
    [ "G-2301-05-P1-commands.h", "d4/db1/_g-2301-05-_p1-commands_8h.html", "d4/db1/_g-2301-05-_p1-commands_8h" ],
    [ "G-2301-05-P1-socket.h", "dd/dce/_g-2301-05-_p1-socket_8h.html", "dd/dce/_g-2301-05-_p1-socket_8h" ],
    [ "G-2301-05-P1-tools.h", "d5/df9/_g-2301-05-_p1-tools_8h.html", "d5/df9/_g-2301-05-_p1-tools_8h" ],
    [ "G-2301-05-P1-types.h", "da/d26/_g-2301-05-_p1-types_8h.html", "da/d26/_g-2301-05-_p1-types_8h" ],
    [ "G-2301-05-P2-audio.h", "d9/dbb/_g-2301-05-_p2-audio_8h.html", "d9/dbb/_g-2301-05-_p2-audio_8h" ],
    [ "G-2301-05-P2-basicCommandsFromServer.h", "da/d15/_g-2301-05-_p2-basic_commands_from_server_8h.html", "da/d15/_g-2301-05-_p2-basic_commands_from_server_8h" ],
    [ "G-2301-05-P2-repliesFromServer.h", "d1/d3b/_g-2301-05-_p2-replies_from_server_8h.html", "d1/d3b/_g-2301-05-_p2-replies_from_server_8h" ],
    [ "G-2301-05-P2-userCommands.h", "d8/dad/_g-2301-05-_p2-user_commands_8h.html", "d8/dad/_g-2301-05-_p2-user_commands_8h" ],
    [ "G-2301-05-P2-userTools.h", "d4/d1f/_g-2301-05-_p2-user_tools_8h.html", "d4/d1f/_g-2301-05-_p2-user_tools_8h" ],
    [ "G-2301-05-P3-ssl.h", "d8/d51/_g-2301-05-_p3-ssl_8h.html", "d8/d51/_g-2301-05-_p3-ssl_8h" ]
];