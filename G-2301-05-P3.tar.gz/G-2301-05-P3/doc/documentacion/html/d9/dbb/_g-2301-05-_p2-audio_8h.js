var _g_2301_05__p2_audio_8h =
[
    [ "BUFLEN", "d9/dbb/_g-2301-05-_p2-audio_8h.html#ad974fe981249f5e84fbf1683b012c9f8", null ],
    [ "PORT", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "SERVER", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a24cd3c37a165a8c4626d9e78df4574ff", null ],
    [ "alreadyRecordingQuery", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a23e6ef186ace7452878618e453a12d6f", null ],
    [ "canIRead", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a70e78aa07a05a7d1d6688220b711fe0d", null ],
    [ "canIWrite", "d9/dbb/_g-2301-05-_p2-audio_8h.html#acddb1a586a8305d216deca1d3bd07c29", null ],
    [ "endAudioTransmission", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a2140fd94315d561f0df0972d18f144cc", null ],
    [ "initiateReciever", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a4d496518d4597c6f8133d109caaf988a", null ],
    [ "initiateSender", "d9/dbb/_g-2301-05-_p2-audio_8h.html#aba2d08b3de022fdec5162252fe5d3dd8", null ],
    [ "playBuffer", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a46e32d8c31f4e0bed7c4a3dd7665ba73", null ],
    [ "writeBuffer", "d9/dbb/_g-2301-05-_p2-audio_8h.html#a197e00439b5ca776c65aba209872f76a", null ]
];