var group___i_r_cssl =
[
    [ "inicializar_nivel_SSL", "d8/db1/group___i_r_cssl.html#inicializar_nivel_SSL", null ],
    [ "fijar_contexto_SSL", "d8/db1/group___i_r_cssl.html#fijar_contexto_SSL", null ],
    [ "conectar_canal_seguro_SSL", "d8/db1/group___i_r_cssl.html#conectar_canal_seguro_SSL", null ],
    [ "aceptar_canal_seguro_SSL", "d8/db1/group___i_r_cssl.html#aceptar_canal_seguro_SSL", null ],
    [ "evaluar_post_connectar_SSL", "d8/db1/group___i_r_cssl.html#evaluar_post_connectar_SSL", null ],
    [ "enviar_datos_SSL", "d8/db1/group___i_r_cssl.html#enviar_datos_SSL", null ],
    [ "recibir_datos_SSL", "d8/db1/group___i_r_cssl.html#recibir_datos_SSL", null ],
    [ "cerrar_canal_SSL", "d8/db1/group___i_r_cssl.html#cerrar_canal_SSL", null ]
];