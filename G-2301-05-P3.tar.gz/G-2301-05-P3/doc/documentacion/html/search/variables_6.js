var searchData=
[
  ['length',['length',['../d4/d4e/structthread_recv_args.html#a9ee64c7b918513891b3834b93ad0e501',1,'threadRecvArgs::length()'],['../d7/d51/structthread_send_args.html#a90bf0058c728d7cea7de336a1251f387',1,'threadSendArgs::length()']]]
];
