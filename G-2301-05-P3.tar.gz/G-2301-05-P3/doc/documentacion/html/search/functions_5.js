var searchData=
[
  ['fijar_5fcontexto_5fssl',['fijar_contexto_SSL',['../d8/d51/_g-2301-05-_p3-ssl_8h.html#a84a295d51a23d2558cbf65f436011dc6',1,'fijar_contexto_SSL(char *CAfile, char *SCfile, char *Pfile, char *CApath):&#160;G-2301-05-P3-ssl.c'],['../d8/d7e/_g-2301-05-_p3-ssl_8c.html#a84a295d51a23d2558cbf65f436011dc6',1,'fijar_contexto_SSL(char *CAfile, char *SCfile, char *Pfile, char *CApath):&#160;G-2301-05-P3-ssl.c']]],
  ['filterusersinchannels',['filterUsersInChannels',['../df/db1/_g-2301-05-_p1-commands_8c.html#a02944755d02164cf484a4c933ed2f0c3',1,'G-2301-05-P1-commands.c']]],
  ['freethreadresources',['freeThreadResources',['../d6/d77/_g-2301-05-_p1-server_8c.html#a492f3eb1b5fd2db5f809828bcaeb8759',1,'freeThreadResources(int socket):&#160;G-2301-05-P1-server.c'],['../d6/d48/servidor___i_r_c_8c.html#a492f3eb1b5fd2db5f809828bcaeb8759',1,'freeThreadResources(int socket):&#160;servidor_IRC.c']]],
  ['fsend_5fparse',['FSend_Parse',['../d9/d8f/_g-2301-05-_p2-basic_commands_from_server_8c.html#ad2ca292b4e5365950f6ea7887abdbc37',1,'G-2301-05-P2-basicCommandsFromServer.c']]]
];
