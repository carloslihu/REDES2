var searchData=
[
  ['opensocket_5ftcp',['openSocket_TCP',['../dd/dce/_g-2301-05-_p1-socket_8h.html#ac0a294efde364937332533e4ecd8d121',1,'openSocket_TCP():&#160;G-2301-05-P1-socket.c'],['../dd/da3/_g-2301-05-_p1-socket_8c.html#ac0a294efde364937332533e4ecd8d121',1,'openSocket_TCP():&#160;G-2301-05-P1-socket.c']]],
  ['opensocket_5fudp',['openSocket_UDP',['../dd/dce/_g-2301-05-_p1-socket_8h.html#abbf23148d1fb659c277f1c4cf3726f54',1,'openSocket_UDP():&#160;G-2301-05-P1-socket.c'],['../dd/da3/_g-2301-05-_p1-socket_8c.html#abbf23148d1fb659c277f1c4cf3726f54',1,'openSocket_UDP():&#160;G-2301-05-P1-socket.c']]]
];
