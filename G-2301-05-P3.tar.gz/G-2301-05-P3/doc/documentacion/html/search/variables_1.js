var searchData=
[
  ['client',['client',['../d3/df7/structthread_args.html#a00c4b9e068a2d36291a8410badf19e85',1,'threadArgs']]],
  ['ctx',['ctx',['../d3/df7/structthread_args.html#ad5433bcc8a463fb4df3ce5912bb11fe3',1,'threadArgs']]]
];
