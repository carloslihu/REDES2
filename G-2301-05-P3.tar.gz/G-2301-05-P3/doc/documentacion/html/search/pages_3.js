var searchData=
[
  ['daemonizar',['daemonizar',['../d1/d75/group___i_r_c_server_tools.html',1,'']]]
];
