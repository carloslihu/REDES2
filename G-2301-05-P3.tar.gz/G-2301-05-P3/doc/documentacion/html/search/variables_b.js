var searchData=
[
  ['sender',['sender',['../d4/d4e/structthread_recv_args.html#abe5ba910d6dc4c312cb722de3ab377f2',1,'threadRecvArgs::sender()'],['../d1/d22/structthread_audio_args.html#ab092ba1f84e458809eb91a5786b281de',1,'threadAudioArgs::sender()']]],
  ['server',['server',['../d3/df7/structthread_args.html#a174501e91471cbe22c45a3a89a932d62',1,'threadArgs']]],
  ['socket',['socket',['../d3/df7/structthread_args.html#a3666576f6b88007cc7b8f26c7da596c8',1,'threadArgs']]],
  ['sockfd',['sockfd',['../d4/d1f/_g-2301-05-_p2-user_tools_8h.html#ad2c8fb3df3a737e0685e902870a611d2',1,'G-2301-05-P2-userTools.h']]],
  ['ssl',['ssl',['../d3/df7/structthread_args.html#ae7c0417fa2881f3546920311fee80311',1,'threadArgs']]],
  ['ssl_5factive',['ssl_active',['../d6/d48/servidor___i_r_c_8c.html#a65183b3bbe4d9d8e2e47ea5eee7b4cce',1,'servidor_IRC.c']]]
];
