var searchData=
[
  ['loginterror',['logIntError',['../d5/df9/_g-2301-05-_p1-tools_8h.html#a6349dfcf345b8d45a1be65e3e17739fe',1,'logIntError(long int returnValue, char *msg):&#160;G-2301-05-P1-tools.c'],['../dd/d7e/_g-2301-05-_p1-tools_8c.html#a6349dfcf345b8d45a1be65e3e17739fe',1,'logIntError(long int returnValue, char *msg):&#160;G-2301-05-P1-tools.c']]],
  ['logpointererror',['logPointerError',['../d5/df9/_g-2301-05-_p1-tools_8h.html#a192fd5bf4f47fe63d449f291f92732a9',1,'logPointerError(void *returnValue, char *msg):&#160;G-2301-05-P1-tools.c'],['../dd/d7e/_g-2301-05-_p1-tools_8c.html#a192fd5bf4f47fe63d449f291f92732a9',1,'logPointerError(void *returnValue, char *msg):&#160;G-2301-05-P1-tools.c']]],
  ['logvoiderror',['logVoidError',['../d5/df9/_g-2301-05-_p1-tools_8h.html#a5b92fdc34c0427eb5cf8360e68aa9287',1,'logVoidError(char *msg):&#160;G-2301-05-P1-tools.c'],['../dd/d7e/_g-2301-05-_p1-tools_8c.html#a5b92fdc34c0427eb5cf8360e68aa9287',1,'logVoidError(char *msg):&#160;G-2301-05-P1-tools.c']]]
];
