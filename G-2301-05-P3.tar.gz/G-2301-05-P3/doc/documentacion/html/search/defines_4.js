var searchData=
[
  ['file_5fbuflen',['FILE_BUFLEN',['../da/d15/_g-2301-05-_p2-basic_commands_from_server_8h.html#ab4280385e15a48712d64d651acb2648d',1,'G-2301-05-P2-basicCommandsFromServer.h']]]
];
