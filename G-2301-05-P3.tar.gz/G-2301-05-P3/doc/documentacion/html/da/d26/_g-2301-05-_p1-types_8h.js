var _g_2301_05__p1_types_8h =
[
    [ "CLIENTNAME", "da/d26/_g-2301-05-_p1-types_8h.html#adcbfe6360d17dafe707c6e9c28ed93e8", null ],
    [ "ERROR", "da/d26/_g-2301-05-_p1-types_8h.html#a8fe83ac76edc595f6b98cd4a4127aed5", null ],
    [ "ERROR_CONTINUE", "da/d26/_g-2301-05-_p1-types_8h.html#aac15417c9e9b175879f9621525227de1", null ],
    [ "ERROR_MALLOC", "da/d26/_g-2301-05-_p1-types_8h.html#a1d14efe4782914b2a1825af2608490f9", null ],
    [ "ERROR_RECV", "da/d26/_g-2301-05-_p1-types_8h.html#a22a59fb7c80bce4f0cc84db66d59c0b6", null ],
    [ "ERROR_SEND", "da/d26/_g-2301-05-_p1-types_8h.html#ab8fafef46c1444f11a84a7d2fdeef171", null ],
    [ "MACRO_QUIT", "da/d26/_g-2301-05-_p1-types_8h.html#a7b3b976361d315b1cfa56d14dc5c0a5c", null ]
];